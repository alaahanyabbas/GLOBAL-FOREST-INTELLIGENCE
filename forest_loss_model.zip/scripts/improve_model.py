import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OrdinalEncoder

RAW_PATH = '../original_files/original_training_data.csv'
df = pd.read_csv(RAW_PATH).sort_values(['country', 'year']).reset_index(drop=True)

df['loss_pct_of_extent2010'] = df['tree_cover_loss_ha'] / df['extent_2010_ha'].replace(0, np.nan)
df['extent_change_ratio'] = df['extent_2010_ha'] / df['extent_2000_ha'].replace(0, np.nan)
df['emissions_per_ha_loss'] = df['gross_emissions_mg_co2e'] / df['tree_cover_loss_ha'].replace(0, np.nan)
df['driver_share_dominant'] = df['dominant_driver_loss_ha'] / df['driver_loss_total_ha'].replace(0, np.nan)
df['loss_accel'] = (df['tree_cover_loss_ha'] - df['loss_lag_1_ha']) - (df['loss_lag_1_ha'] - df['loss_lag_2_ha'])

grp = df.groupby('country')['tree_cover_loss_ha']
df['country_hist_mean_loss'] = grp.transform(lambda s: s.expanding().mean().shift(1))
df['country_hist_std_loss'] = grp.transform(lambda s: s.expanding().std().shift(1))

df['loss_lag_3_ha'] = grp.shift(3)
df['loss_lag_4_ha'] = grp.shift(4)
df['loss_rolling_5yr_std_ha'] = grp.transform(lambda s: s.rolling(5, min_periods=2).std())
df['loss_zscore_vs_hist'] = (df['tree_cover_loss_ha'] - df['country_hist_mean_loss']) / df['country_hist_std_loss'].replace(0, np.nan)
df['is_anomalous_year'] = (df['loss_zscore_vs_hist'].abs() > 2).astype(int)
df['loss_trend_3yr'] = grp.transform(lambda s: s.diff().rolling(3, min_periods=2).mean())
df['extent_size_bucket'] = pd.qcut(df['extent_2010_ha'], q=4, labels=False, duplicates='drop')

enc = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
df['country_enc'] = enc.fit_transform(df[['country']])

target_col = 'target_next_year_loss_ha'

base_feats = ['area_ha','extent_2000_ha','extent_2010_ha','year','tree_cover_loss_ha',
              'loss_lag_1_ha','loss_lag_2_ha','loss_rolling_3yr_avg_ha','loss_yoy_pct',
              'driver_loss_total_ha','driver_count','dominant_driver_loss_ha',
              'gross_emissions_mg_co2e','loss_pct_of_extent2010','extent_change_ratio',
              'emissions_per_ha_loss','driver_share_dominant','loss_accel',
              'country_hist_mean_loss','country_hist_std_loss','country_enc']

new_feats = base_feats + ['loss_lag_3_ha','loss_lag_4_ha','loss_rolling_5yr_std_ha',
                           'is_anomalous_year','loss_trend_3yr','extent_size_bucket']

train_mask = df['year'] < 2021
test_mask = df['year'].between(2021, 2024)

def run(feats, log_target, name):
    X_train, y_train = df.loc[train_mask, feats], df.loc[train_mask, target_col]
    X_test, y_test = df.loc[test_mask, feats], df.loc[test_mask, target_col]
    y_fit = np.log1p(y_train) if log_target else y_train
    m = HistGradientBoostingRegressor(random_state=42, max_iter=300, learning_rate=0.05)
    m.fit(X_train, y_fit)
    pred = m.predict(X_test)
    if log_target:
        pred = np.expm1(pred)
    pred = np.clip(pred, 0, None)
    mae = mean_absolute_error(y_test, pred)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    r2 = r2_score(y_test, pred)
    big = y_test > 500_000
    mae_big = mean_absolute_error(y_test[big], pred[big])
    print(f'{name:35s} MAE={mae:>10,.0f}  RMSE={rmse:>12,.0f}  R2={r2:6.4f}   MAE(big)={mae_big:>12,.0f}')
    return m, feats

run(base_feats, False, 'A: base feats, no log')
run(base_feats, True,  'B: base feats, + log target')
run(new_feats,  False, 'C: new feats, no log')
run(new_feats,  True,  'D: new feats, + log target')
