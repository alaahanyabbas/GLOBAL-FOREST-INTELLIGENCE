import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OrdinalEncoder
import joblib
import json

RAW_PATH = '../original_files/original_training_data.csv'
OUT_DIR = '../outputs'

df = pd.read_csv(RAW_PATH)
df = df.sort_values(['country', 'year']).reset_index(drop=True)

# ---------------------------------------------------------------
# 1. Recreate original engineered features (as used by prior model)
# ---------------------------------------------------------------
df['loss_pct_of_extent2010'] = df['tree_cover_loss_ha'] / df['extent_2010_ha'].replace(0, np.nan)
df['extent_change_ratio'] = df['extent_2010_ha'] / df['extent_2000_ha'].replace(0, np.nan)
df['emissions_per_ha_loss'] = df['gross_emissions_mg_co2e'] / df['tree_cover_loss_ha'].replace(0, np.nan)
df['driver_share_dominant'] = df['dominant_driver_loss_ha'] / df['driver_loss_total_ha'].replace(0, np.nan)
df['loss_accel'] = (df['tree_cover_loss_ha'] - df['loss_lag_1_ha']) - (df['loss_lag_1_ha'] - df['loss_lag_2_ha'])

# expanding (leak-safe) country history stats, shifted by 1 year
grp = df.groupby('country')['tree_cover_loss_ha']
df['country_hist_mean_loss'] = grp.transform(lambda s: s.expanding().mean().shift(1))
df['country_hist_std_loss'] = grp.transform(lambda s: s.expanding().std().shift(1))

# ---------------------------------------------------------------
# 2. NEW features addressing the weaknesses identified earlier
# ---------------------------------------------------------------
# a) longer lag history (captures multi-year cycles, not just t-1/t-2)
df['loss_lag_3_ha'] = grp.shift(3)
df['loss_lag_4_ha'] = grp.shift(4)

# b) rolling volatility (5yr std) -> helps model learn "this country is erratic"
df['loss_rolling_5yr_std_ha'] = grp.transform(lambda s: s.rolling(5, min_periods=2).std())

# c) anomaly flag: was the CURRENT year itself a statistical outlier vs country history?
#    (z-score of this year's loss vs expanding history BEFORE this year)
df['loss_zscore_vs_hist'] = (df['tree_cover_loss_ha'] - df['country_hist_mean_loss']) / df['country_hist_std_loss'].replace(0, np.nan)
df['is_anomalous_year'] = (df['loss_zscore_vs_hist'].abs() > 2).astype(int)

# d) trend momentum over 3 years (direction, not just single yoy%)
df['loss_trend_3yr'] = grp.transform(lambda s: s.diff().rolling(3, min_periods=2).mean())

# e) country size bucket (helps model separate "small country % noise" from big emitters)
df['extent_size_bucket'] = pd.qcut(df['extent_2010_ha'], q=4, labels=False, duplicates='drop')

# ---------------------------------------------------------------
# 3. Clean up: drop near-zero / negative-importance noisy features
#    identified previously (driver_share_dominant, dominant_driver_loss_ha,
#    loss_rolling_3yr_avg_ha, loss_pct_of_extent2010, country_hist_mean_loss,
#    threshold) from the FINAL feature set, but keep the better replacements.
# ---------------------------------------------------------------
drop_cols = [
    'driver_share_dominant', 'dominant_driver_loss_ha', 'loss_rolling_3yr_avg_ha',
    'loss_pct_of_extent2010', 'threshold', 'target_next_year', 'dominant_driver'
]

target_col = 'target_next_year_loss_ha'
feature_cols = [c for c in df.columns if c not in drop_cols + [target_col, 'country']]

# encode country as ordinal (kept, prior model gave it near-zero importance but harmless)
enc = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
df['country_enc'] = enc.fit_transform(df[['country']])
feature_cols = [c for c in feature_cols if c != 'country'] + ['country_enc']

X = df[feature_cols]
y = df[target_col]

# ---------------------------------------------------------------
# 4. Time-based split (train < 2021, test = 2021-2024) - matches
#    original error_summary evaluation window, avoids leakage.
# ---------------------------------------------------------------
train_mask = df['year'] < 2021
test_mask = df['year'].between(2021, 2024)

X_train, y_train = X[train_mask], y[train_mask]
X_test, y_test = X[test_mask], y[test_mask]

print(f'Train rows: {len(X_train)}  Test rows: {len(X_test)}')

# ---------------------------------------------------------------
# 5. Train BASELINE (no log-transform, old feature set) for fair comparison
# ---------------------------------------------------------------
baseline_features = [c for c in feature_cols if c not in [
    'loss_lag_3_ha', 'loss_lag_4_ha', 'loss_rolling_5yr_std_ha',
    'loss_zscore_vs_hist', 'is_anomalous_year', 'loss_trend_3yr', 'extent_size_bucket'
]]
model_baseline = HistGradientBoostingRegressor(random_state=42)
model_baseline.fit(X_train[baseline_features], y_train)
pred_baseline = model_baseline.predict(X_test[baseline_features])
pred_baseline = np.clip(pred_baseline, 0, None)

# ---------------------------------------------------------------
# 6. Train IMPROVED model: new features + log1p target transform
# ---------------------------------------------------------------
y_train_log = np.log1p(y_train)
model_improved = HistGradientBoostingRegressor(random_state=42, max_iter=300, learning_rate=0.05)
model_improved.fit(X_train, y_train_log)
pred_log = model_improved.predict(X_test)
pred_improved = np.expm1(pred_log)
pred_improved = np.clip(pred_improved, 0, None)

# ---------------------------------------------------------------
# 7. Evaluate both
# ---------------------------------------------------------------
def metrics(y_true, y_pred, name):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    print(f'{name:20s}  MAE={mae:,.1f}  RMSE={rmse:,.1f}  R2={r2:.4f}')
    return {'model': name, 'MAE': mae, 'RMSE': rmse, 'R2': r2}

print()
results = []
results.append(metrics(y_test, pred_baseline, 'Baseline (old)'))
results.append(metrics(y_test, pred_improved, 'Improved (new)'))

# Focus on the previously worst cases (large countries / extreme years)
big_mask = y_test > 500_000
print()
print('--- Performance on large-loss country-years (>500k ha actual) ---')
metrics(y_test[big_mask], pred_baseline[big_mask], 'Baseline - big')
metrics(y_test[big_mask], pred_improved[big_mask], 'Improved - big')

# ---------------------------------------------------------------
# 8. Save outputs
# ---------------------------------------------------------------
import os
os.makedirs(OUT_DIR, exist_ok=True)

pd.DataFrame(results).to_csv(f'{OUT_DIR}/model_comparison_before_after.csv', index=False)

error_df = df.loc[test_mask, ['country', 'year']].copy()
error_df['actual_loss_ha'] = y_test.values
error_df['predicted_loss_ha_baseline'] = pred_baseline
error_df['predicted_loss_ha_improved'] = pred_improved
error_df['abs_error_baseline'] = (error_df['actual_loss_ha'] - error_df['predicted_loss_ha_baseline']).abs()
error_df['abs_error_improved'] = (error_df['actual_loss_ha'] - error_df['predicted_loss_ha_improved']).abs()
error_df.to_csv(f'{OUT_DIR}/error_summary_before_after.csv', index=False)

imp = pd.Series(model_improved.feature_importances_ if hasattr(model_improved, 'feature_importances_') else None)
# HistGradientBoostingRegressor has no feature_importances_ by default -> use permutation importance
from sklearn.inspection import permutation_importance
perm = permutation_importance(model_improved, X_test, np.log1p(y_test), n_repeats=5, random_state=42, n_jobs=-1)
imp_df = pd.DataFrame({'feature': feature_cols, 'importance': perm.importances_mean}).sort_values('importance', ascending=False)
imp_df.to_csv(f'{OUT_DIR}/feature_importance_improved.csv', index=False)

joblib.dump(model_improved, f'{OUT_DIR}/best_model_improved.joblib')

print()
print('Top 10 features (improved model, permutation importance):')
print(imp_df.head(10).to_string(index=False))

print()
print('Saved:')
print(' -', f'{OUT_DIR}/model_comparison_before_after.csv')
print(' -', f'{OUT_DIR}/error_summary_before_after.csv')
print(' -', f'{OUT_DIR}/feature_importance_improved.csv')
print(' -', f'{OUT_DIR}/best_model_improved.joblib')
