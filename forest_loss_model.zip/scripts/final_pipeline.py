import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OrdinalEncoder
from sklearn.inspection import permutation_importance
import joblib, os

RAW_PATH = '../original_files/original_training_data.csv'
OUT_DIR = '../outputs'
os.makedirs(OUT_DIR, exist_ok=True)

df = pd.read_csv(RAW_PATH).sort_values(['country', 'year']).reset_index(drop=True)

# ---- recreate original engineered features ----
df['loss_pct_of_extent2010'] = df['tree_cover_loss_ha'] / df['extent_2010_ha'].replace(0, np.nan)
df['extent_change_ratio'] = df['extent_2010_ha'] / df['extent_2000_ha'].replace(0, np.nan)
df['emissions_per_ha_loss'] = df['gross_emissions_mg_co2e'] / df['tree_cover_loss_ha'].replace(0, np.nan)
df['driver_share_dominant'] = df['dominant_driver_loss_ha'] / df['driver_loss_total_ha'].replace(0, np.nan)
df['loss_accel'] = (df['tree_cover_loss_ha'] - df['loss_lag_1_ha']) - (df['loss_lag_1_ha'] - df['loss_lag_2_ha'])

grp = df.groupby('country')['tree_cover_loss_ha']
df['country_hist_mean_loss'] = grp.transform(lambda s: s.expanding().mean().shift(1))
df['country_hist_std_loss'] = grp.transform(lambda s: s.expanding().std().shift(1))

# ---- NEW features ----
df['loss_lag_3_ha'] = grp.shift(3)
df['loss_lag_4_ha'] = grp.shift(4)
df['loss_rolling_5yr_std_ha'] = grp.transform(lambda s: s.rolling(5, min_periods=2).std())
df['loss_zscore_vs_hist'] = (df['tree_cover_loss_ha'] - df['country_hist_mean_loss']) / df['country_hist_std_loss'].replace(0, np.nan)
df['is_anomalous_year'] = (df['loss_zscore_vs_hist'].abs() > 2).astype(int)
df['loss_trend_3yr'] = grp.transform(lambda s: s.diff().rolling(3, min_periods=2).mean())
df['extent_size_bucket'] = pd.qcut(df['extent_2010_ha'], q=4, labels=False, duplicates='drop')

enc = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
df['country_enc'] = enc.fit_transform(df[['country']])

target_col = 'target_next_year_loss_ha'

base_feats = ['area_ha','extent_2000_ha','extent_2010_ha','year','tree_cover_loss_ha',
              'loss_lag_1_ha','loss_lag_2_ha','loss_rolling_3yr_avg_ha','loss_yoy_pct',
              'driver_loss_total_ha','driver_count','dominant_driver_loss_ha',
              'gross_emissions_mg_co2e','loss_pct_of_extent2010','extent_change_ratio',
              'emissions_per_ha_loss','driver_share_dominant','loss_accel',
              'country_hist_mean_loss','country_hist_std_loss','country_enc']

new_feats = base_feats + ['loss_lag_3_ha','loss_lag_4_ha','loss_rolling_5yr_std_ha',
                           'is_anomalous_year','loss_trend_3yr','extent_size_bucket']

train_mask = df['year'] < 2021
test_mask = df['year'].between(2021, 2024)

X_train_b, y_train = df.loc[train_mask, base_feats], df.loc[train_mask, target_col]
X_test_b, y_test = df.loc[test_mask, base_feats], df.loc[test_mask, target_col]
X_train_n = df.loc[train_mask, new_feats]
X_test_n = df.loc[test_mask, new_feats]

# ---- Model A: original-style features, squared_error (reproduces the old approach) ----
model_A = HistGradientBoostingRegressor(random_state=42, max_iter=300, learning_rate=0.05)
model_A.fit(X_train_b, y_train)

# ---- Model G: new features (lags/anomaly/volatility) + absolute_error loss
#      (squared_error was tried with new feats too - see ablation - absolute_error won) ----
model_G = HistGradientBoostingRegressor(random_state=42, max_iter=300, learning_rate=0.05, loss='absolute_error')
model_G.fit(X_train_n, y_train)

pred_A = np.clip(model_A.predict(X_test_b), 0, None)
pred_G = np.clip(model_G.predict(X_test_n), 0, None)
pred_blend = 0.5 * pred_A + 0.5 * pred_G

def metrics_row(y_true, y_pred, name):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    big = y_true > 500_000
    mae_big = mean_absolute_error(y_true[big], y_pred[big])
    return {'model': name, 'MAE': mae, 'RMSE': rmse, 'R2': r2, 'MAE_big_countries': mae_big}

rows = [
    metrics_row(y_test, pred_A, 'Reproduced original (base feats)'),
    metrics_row(y_test, pred_G, 'New feats + absolute_error loss'),
    metrics_row(y_test, pred_blend, 'FINAL: Blend (A + G)'),
]
comp = pd.DataFrame(rows)
print(comp.to_string(index=False))
comp.to_csv(f'{OUT_DIR}/model_comparison_before_after.csv', index=False)

# ---- error summary with blend predictions ----
error_df = df.loc[test_mask, ['country', 'year']].copy()
error_df['actual_loss_ha'] = y_test.values
error_df['predicted_loss_ha_old_approach'] = pred_A
error_df['predicted_loss_ha_improved_blend'] = pred_blend
error_df['abs_error_old'] = (error_df['actual_loss_ha'] - error_df['predicted_loss_ha_old_approach']).abs()
error_df['abs_error_improved'] = (error_df['actual_loss_ha'] - error_df['predicted_loss_ha_improved_blend']).abs()
error_df['improved_by_ha'] = error_df['abs_error_old'] - error_df['abs_error_improved']
error_df.sort_values('actual_loss_ha', ascending=False).to_csv(f'{OUT_DIR}/error_summary_before_after.csv', index=False)

# ---- permutation importance for model_G (the one carrying new features) ----
perm = permutation_importance(model_G, X_test_n, y_test, n_repeats=5, random_state=42, n_jobs=-1)
imp_df = pd.DataFrame({'feature': new_feats, 'importance': perm.importances_mean}).sort_values('importance', ascending=False)
imp_df.to_csv(f'{OUT_DIR}/feature_importance_improved.csv', index=False)
print()
print('Top 12 features (new model):')
print(imp_df.head(12).to_string(index=False))

# ---- save both component models + a small blend wrapper ----
joblib.dump({'model_A_base_feats': model_A, 'model_G_new_feats': model_G,
             'base_feats': base_feats, 'new_feats': new_feats,
             'blend_weights': {'A': 0.5, 'G': 0.5}},
            f'{OUT_DIR}/best_model_improved.joblib')

print()
print('Biggest remaining misses (blend model):')
print(error_df.sort_values('abs_error_improved', ascending=False)[['country','year','actual_loss_ha','predicted_loss_ha_improved_blend','abs_error_improved']].head(10).to_string(index=False))
