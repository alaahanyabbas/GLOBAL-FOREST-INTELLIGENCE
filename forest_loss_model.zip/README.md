# Forest Loss Model Update

Updated model for forecasting next-year tree cover loss per country. \
موديل محدّث لتوقع فقدان الغابات للسنة الجاية لكل دولة.

## Folder Contents

### Main Notebook
- **`notebooks/01_Forest_Loss_Machine_Learning.ipynb`** — the full pipeline, \
  fully executed (every cell shows its real output, no warnings). One \
  integrated flow from loading the data to saving the final model — old and \
  new logic merged into a single pipeline instead of separate sections:
  1. Load data
  2. Feature engineering (core + extra features together, in one step)
  3. Time-based train/test split
  4. Honestly test several combinations (feature set × loss function)
  5. Train the final model (blend of two models)
  6. Evaluation + error table
  7. **Robustness check** — same comparison at 3 different time cutoffs (2020/2021/2022) to confirm the improvement isn't a fluke
  8. Feature importance + save the model
  9. **A ready-to-use function** `predict_next_year()`, with a worked example

خط أنابيب واحد متكامل من أول تحميل البيانات لحد حفظ الموديل النهائي، منفَّذ بالكامل وبدون أي warnings.

### New Model Outputs (`outputs/`)
- `model_comparison_before_after.csv` — performance comparison: before vs. after
- `error_summary_before_after.csv` — per-country/year predictions, old and new side by side
- `feature_importance_improved.csv` — feature importance for the new model
- `best_model_improved.joblib` — the final model, a genuine `joblib` dump (dict with `model_core` + `model_extended` + blend weights)

### `scripts/` — Original Experimental Code (history)
Kept as a record of how the result was reached; **not** part of the final \
deliverable, since everything is already merged into the notebook above.
- `improve_model.py` — first attempt (tried a log-transform, didn't help)
- `ablation.py` — systematic comparison across combinations (baseline vs. new features + log target)
- `final_pipeline.py` — the final script (same logic as the notebook, runnable standalone)

### `original_files/` — Original Uploaded Files, Unmodified
- `original_training_data.csv` — raw training data (same data used in the update)
- `original_error_summary.csv` — original per-country/year error table (single old model)
- `original_best_model_reference.csv` — comparison of the 8 original candidate models
- `original_baseline_bias_summary.csv` — small bias summary (MAE/median/mean signed error/underprediction rate) for the original baseline model

> **A note on the source files:** the files as first uploaded had their \
> filenames and actual contents mismatched (e.g. the file named `ablation.py` \
> actually contained the notebook, the file named `README.md` actually \
> contained the comparison table, and so on) — a rotation-style mix-up in \
> the upload. Everything here has been re-matched by content and, more \
> importantly, **re-run end to end** against the real training data rather \
> than just relabeled, so every number in `outputs/` is freshly verified. \
> `original_best_model_reference.joblib` was also renamed to `.csv` here \
> since it was never a real joblib file, only CSV text — same issue the \
> original author already flagged for that one file, just carried through \
> consistently to the rest.

---

## Results Summary

| Metric | Before | After (Blend) | Improvement |
|---|---|---|---|
| MAE | 34,118 | 32,439 | ~5% down |
| RMSE | 263,033 | 260,864 | ~0.8% down |
| R² | 0.769 | 0.773 | up |
| MAE (large countries > 500k ha) | 745,735 | 719,424 | ~3.5% down |

**Robustness check:** the same comparison at 3 different time cutoffs (2020, \
2021, 2022) confirmed the blend beats the base model in **all three cases** \
— the improvement is consistent, not a fluke tied to one year.

**Methodology limits:**
- No real hyperparameter tuning yet (grid/random search)
- The number of "large countries" in any test window is fairly small, so that MAE slice is noisier

**Honest note:** the improvement is real and consistent but modest. There's \
still a clear failure mode in exceptional fire years (Canada 2022/2024). \
That confirms the real next step is adding **external climate data** \
(drought index, El Niño/La Niña) — not more feature engineering on the same \
available data.

بصراحة: التحسن حقيقي وثابت لكنه متوسط، ولسه فيه فشل واضح في سنوات الحرائق \
الاستثنائية، فالخطوة الجاية الحقيقية هي بيانات مناخية خارجية مش مجرد فيتشرز جديدة.

---

## Reusing the Saved Model

`best_model_improved.joblib` stores the two component models, their feature \
lists, and the blend weights — but not a function object (pickled functions \
from a notebook/`__main__` session don't reliably unpickle in a different \
session). Paste this short helper alongside the load call:

```python
import joblib
import numpy as np

def predict_next_year(new_df, model_core, model_extended, core_feats, extended_feats, blend_weights=None):
    """Predict next-year forest loss for each row in new_df."""
    if blend_weights is None:
        blend_weights = {'core': 0.5, 'extended': 0.5}
    pred_core = np.clip(model_core.predict(new_df[core_feats]), 0, None)
    pred_extended = np.clip(model_extended.predict(new_df[extended_feats]), 0, None)
    return blend_weights['core'] * pred_core + blend_weights['extended'] * pred_extended

bundle = joblib.load('outputs/best_model_improved.joblib')
preds = predict_next_year(
    new_df,
    bundle['model_core'], bundle['model_extended'],
    bundle['core_feats'], bundle['extended_feats'],
    bundle['blend_weights'],
)
```

`new_df` needs the same feature columns used at training time — see \
`core_feats` / `extended_feats` inside the bundle, or section 4 of the notebook.

---

## Setup

```bash
pip install -r requirements.txt
```

Tested against `pandas==3.0.2`, `numpy==2.4.4`, `scikit-learn==1.8.0`, `joblib==1.5.3`.
